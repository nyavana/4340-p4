from pathlib import Path
import re, subprocess, textwrap

base = Path('/mnt/data')
md_path = base/'4340-final-report.md'
text = md_path.read_text(encoding='utf-8')

# Normalize a few characters that often create fragile LaTeX/PDF output.
# Keep section and multiply symbols as LaTeX-friendly text later through escaping in raw tables.
text = text.replace('—', '---')
text = text.replace('–', '--')
text = text.replace('−', '-')
text = text.replace('“', '``').replace('”', "''")
text = text.replace('’', "'").replace('‘', "`")
text = text.replace('≈', r'$\approx$')
text = text.replace('→', '->')
text = text.replace('←', '<-')
text = text.replace('↔', '<->')
text = text.replace('§', 'Sec. ')
text = text.replace('×', 'x')

lines = text.splitlines()
# Extract title and author/course lines.
title = lines[0].lstrip('#').strip()
author_line = lines[2].strip()
course_line = lines[4].strip()
# Extract abstract and body.
abs_idx = next(i for i,l in enumerate(lines) if l.strip() == '## Abstract')
next_h2 = next(i for i in range(abs_idx+1, len(lines)) if lines[i].startswith('## '))
abstract_md = '\n'.join(lines[abs_idx+1:next_h2]).strip()
body_md = '\n'.join(lines[next_h2:]).strip()

# Remove explicit Roman section labels from headings; IEEEtran adds them.
roman_pat = re.compile(r'^(#+)\s+([IVXLCDM]+(?:\.[A-Z0-9]+)*\.?)[\s]+(.+)$', re.M)
def clean_heading(m):
    hashes, num, rest = m.group(1), m.group(2), m.group(3)
    # ## I. -> # ; ### V.A. -> ## ; keep deeper levels one lower too.
    if len(hashes) >= 2:
        hashes = hashes[:-1]
    return f"{hashes} {rest}"
body_md = roman_pat.sub(clean_heading, body_md)

# Replace References with a bibliography block.
refs_start = body_md.find('\n# References')
if refs_start != -1:
    body_no_refs = body_md[:refs_start].rstrip()
else:
    body_no_refs = body_md

bib_block = r'''
\begin{thebibliography}{5}
\bibitem{hennessy}
J. L. Hennessy and D. A. Patterson, \textit{Computer Architecture: A Quantitative Approach}, 6th ed. Cambridge, MA, USA: Morgan Kaufmann, 2017.

\bibitem{mcfarling}
S. McFarling, ``Combining Branch Predictors,'' Digital Equipment Corp. Western Research Laboratory, Palo Alto, CA, USA, Tech. Note TN-36, Jun. 1993.

\bibitem{verisimplev}
EECS 4340 course staff, ``VeriSimpleV in-order RISC-V pipeline starter,'' Project 3 release, Columbia University, Spring 2026.

\bibitem{riscv}
\textit{The RISC-V Instruction Set Manual, Volume I: User-Level ISA}, Document Version 20191213, RISC-V Foundation, Dec. 2019.

\bibitem{yeh-patt}
T.-Y. Yeh and Y. N. Patt, ``Two-level adaptive training branch prediction,'' in \textit{Proc. 24th Annu. Int. Symp. Microarchitecture (MICRO-24)}, Albuquerque, NM, USA, Nov. 1991, pp. 51--61.
\end{thebibliography}
'''
body_md = body_no_refs + '\n\n' + bib_block

# Convert literal reference mentions [1]-[5] to non-breaking text citations? Leave as numeric references.
# Handle figure placeholders with raw LaTeX.
figs = {
    1: ("fig1_pipeline_fixed.png", "Top-level pipeline block diagram. Stages, buses, and the sideband signals for early tag broadcast and store completion.", "fig:pipeline", "\\textwidth", None),
    2: ("fig2_predictor_fixed.png", "gshare predictor with Branch Target Buffer and Return Address Stack.", "fig:predictor", "0.72\\textwidth", "height=0.68\\textheight,keepaspectratio,"),
    3: ("fig3_dcache_fixed.png", "D-cache organization with tag/set/offset decode, two-way array, LRU state, miss/fill control, stream buffer, and memory-bus path.", "fig:dcache", "\\textwidth", None),
    4: ("fig4_stlf_fixed.png", "Store-to-load forwarding lanes in the Load-Store Queue.", "fig:stlf", "\\textwidth", None),
    5: ("fig5_timing_fixed.png", "Early-tag-broadcast timing for a pipelined multiply and a dependent reservation-station entry.", "fig:timing", "0.92\\textwidth", None),
}

def fig_block(n):
    fname, cap, label, width, extra = figs[n]
    opts = f"width={width}"
    if extra:
        opts = extra + opts
    return textwrap.dedent(f'''

\\begin{{figure*}}[!t]
  \\centering
  \\includegraphics[{opts}]{{{fname}}}
  \\caption{{{cap}}}
  \\label{{{label}}}
\\end{{figure*}}

''').strip()

for n in figs:
    if n == 5:
        # Keep the source text reference, but move the actual figure later so LaTeX numbering follows Fig. 1--5.
        body_md = re.sub(rf'^\[FIGURE {n}:.*?\]\s*$', '', body_md, flags=re.M)
    else:
        body_md = re.sub(rf'^\[FIGURE {n}:.*?\]\s*$', lambda m, n=n: fig_block(n), body_md, flags=re.M)
# Place the ETB timing diagram after Fig. 4 so the automatic numbering matches the placeholder number.
fig4 = fig_block(4)
if fig4 in body_md:
    body_md = body_md.replace(fig4, fig4 + '\n\n' + fig_block(5), 1)

# Table utilities.
def tex_escape(s: str) -> str:
    s = s.strip()
    # remove markdown emphasis
    bold = False
    if s.startswith('**') and s.endswith('**'):
        bold = True
        s = s[2:-2]
    s = s.replace('†', r'$\dag$')
    s = s.replace('§', r'\S')
    s = s.replace('×', r'$\times$')
    s = s.replace('Δ', r'$\Delta$')
    # Preserve inline code as teletype.
    def code_repl(m):
        inner = m.group(1)
        inner = inner.replace('\\', r'\textbackslash{}')
        for a,b in [('&', r'\&'), ('%', r'\%'), ('_', r'\_'), ('#', r'\#'), ('{', r'\{'), ('}', r'\}'), ('$', r'\$')]:
            inner = inner.replace(a,b)
        return r'\texttt{' + inner + '}'
    s = re.sub(r'`([^`]+)`', code_repl, s)
    # General escapes outside code
    repl = {
        '\\': r'\textbackslash{}',
        '&': r'\&',
        '%': r'\%',
        '_': r'\_',
        '#': r'\#',
        '{': r'\{',
        '}': r'\}',
    }
    # Do not re-escape LaTeX macros inserted above; temporarily protect them.
    protected = []
    def prot(m):
        protected.append(m.group(0))
        return f'@@PROT{len(protected)-1}@@'
    s = re.sub(r'\$\\(?:dag|times|Delta|approx)\$|\\S', prot, s)
    for a,b in repl.items():
        s = s.replace(a,b)
    for i,p in enumerate(protected):
        s = s.replace(f'@@PROT{i}@@', p)
    # Small markdown italics cleanup for references isn't used in tables, but keep simple.
    if bold:
        s = r'\textbf{' + s + '}'
    return s

def parse_pipe_table(table_text):
    rows=[]
    for line in table_text.strip().splitlines():
        line=line.strip()
        if not line.startswith('|'):
            continue
        cells=[c.strip() for c in line.strip('|').split('|')]
        # skip separator rows
        if all(re.fullmatch(r':?-{3,}:?', c) for c in cells):
            continue
        rows.append(cells)
    return rows

def make_latex_rows(rows, bold_last=False):
    out=[]
    for r in rows:
        cells=[tex_escape(c) for c in r]
        out.append(' & '.join(cells) + r' \\')
    return '\n'.join(out)

def replace_table(md, marker, label, colspec, size_cmd, note=''):
    # Find paragraph starting marker, then the next pipe table.
    pat = re.compile(rf'^{re.escape(marker)}([^\n]*(?:\n(?!\n)[^\n]*)*)\n\n((?:\|[^\n]*\n)+)', re.M)
    m = pat.search(md)
    if not m:
        print('WARN: table marker not found', marker)
        return md
    caption = (marker + m.group(1)).strip()
    # Remove leading TABLE X. from caption text.
    caption = re.sub(r'^TABLE\s+[IVX]+\.\s*', '', caption).strip()
    # For LaTeX caption, strip markdown inline code/emphasis through simple escaping.
    caption_tex = tex_escape(caption)
    rows = parse_pipe_table(m.group(2))
    header, data = rows[0], rows[1:]
    header_tex = ' & '.join(tex_escape(c) for c in header) + r' \\'
    data_tex = make_latex_rows(data)
    block = textwrap.dedent(f'''

\\begin{{table*}}[!t]
\\caption{{{caption_tex}}}
\\label{{{label}}}
\\centering
{size_cmd}
\\setlength{{\\tabcolsep}}{{3.5pt}}
\\renewcommand{{\\arraystretch}}{{1.08}}
\\begin{{tabularx}}{{\\textwidth}}{{{colspec}}}
\\toprule
{header_tex}
\\midrule
{data_tex}
\\bottomrule
\\end{{tabularx}}
{note}
\\end{{table*}}

''').strip()
    return md[:m.start()] + block + md[m.end():]

# Use more specific markers. The regex captures long caption paragraph until blank line.
body_md = replace_table(
    body_md,
    'TABLE I.',
    'tab:features',
    r'c >{\raggedright\arraybackslash}p{0.20\textwidth} X >{\raggedright\arraybackslash}p{0.12\textwidth}',
    r'\footnotesize'
)
body_md = replace_table(
    body_md,
    'TABLE II.',
    'tab:performance',
    r'>{\raggedright\arraybackslash}X r r r r r',
    r'\scriptsize'
)
body_md = replace_table(
    body_md,
    'TABLE III.',
    'tab:attribution',
    r'>{\raggedright\arraybackslash}p{0.28\textwidth} r >{\raggedright\arraybackslash}X >{\raggedright\arraybackslash}p{0.13\textwidth}',
    r'\footnotesize'
)

# After references block append, avoid Pandoc interpreting bibliography raw block as markdown? It should pass raw tex.
preprocessed = base/'4340-final-report-preprocessed.md'
preprocessed.write_text(body_md, encoding='utf-8')

# Convert abstract and body to LaTeX.
def pandoc_convert(md_str):
    p = subprocess.run(['pandoc','-f','markdown+raw_tex','-t','latex','--top-level-division=section','--listings'],
                       input=md_str.encode('utf-8'), stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    return p.stdout.decode('utf-8')
abstract_tex = pandoc_convert(abstract_md)
body_tex = pandoc_convert(body_md)

# Pandoc escapes $\approx$ into math if left as raw? It may be okay. Ensure no unicode hangs.
# Build full IEEEtran TeX.
tex = rf'''
\documentclass[conference]{{IEEEtran}}
\IEEEoverridecommandlockouts
\usepackage[T1]{{fontenc}}
\usepackage[utf8]{{inputenc}}
\usepackage{{newtxtext,newtxmath}}
\usepackage{{graphicx}}
\usepackage{{booktabs}}
\usepackage{{tabularx}}
\usepackage{{array}}
\usepackage{{adjustbox}}
\usepackage{{amsmath}}
\usepackage{{listings}}
\usepackage{{xcolor}}
\usepackage{{stfloats}}
\usepackage{{url}}
\usepackage[hidelinks]{{hyperref}}
\usepackage{{microtype}}
\usepackage{{placeins}}
\graphicspath{{{{./}}}}

\newcommand{{\passthrough}}[1]{{#1}}
\lstset{{
  basicstyle=\ttfamily\footnotesize,
  breaklines=true,
  columns=fullflexible,
  frame=single,
  xleftmargin=0.5em,
  xrightmargin=0.5em
}}

\title{{{title}}}
\author{{
\IEEEauthorblockN{{Chenhao Yang, Xuepeng Han, Gavin Zou, Pingchuan Dong, Hins Lyu, Xueer Qian}}
\IEEEauthorblockA{{EECS 4340, Columbia University\\
\{{cy2822, xh2718, cz2931, pd2827, ql2585, xq2259\}}@columbia.edu}}
}}

\begin{{document}}
\maketitle

\begin{{abstract}}
{abstract_tex.strip()}
\end{{abstract}}

{body_tex}

\end{{document}}
'''
tex_path = base/'4340-final-report-ieee.tex'
tex_path.write_text(tex, encoding='utf-8')
print(tex_path)
